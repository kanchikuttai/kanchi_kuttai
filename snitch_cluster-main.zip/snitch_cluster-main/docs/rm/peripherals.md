# Snitch Cluster peripherals

This section documents the registers exposed by the Snitch cluster to interface with various cluster-level peripherals, including the performance counters.

{% include-markdown '../generated/peripherals.md' %}
