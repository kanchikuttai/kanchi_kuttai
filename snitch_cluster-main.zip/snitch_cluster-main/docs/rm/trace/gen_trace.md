<<<<<<< HEAD
::: gen_trace
=======
::: gen_trace
>>>>>>> c744477... trace: Refactor and prepare for DMA trace generation
