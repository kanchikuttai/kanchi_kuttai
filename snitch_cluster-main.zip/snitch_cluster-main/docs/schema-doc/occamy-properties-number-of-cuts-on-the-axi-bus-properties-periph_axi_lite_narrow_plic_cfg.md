# Untitled integer in Occamy System Schema Schema

```txt
http://pulp-platform.org/snitch/occamy.schema.json#/properties/cuts/properties/periph_axi_lite_narrow_plic_cfg
```

axi lite narrow cuts before regbus translation for plic_cfg

| Abstract            | Extensible | Status         | Identifiable            | Custom Properties | Additional Properties | Access Restrictions | Defined In                                                       |
| :------------------ | :--------- | :------------- | :---------------------- | :---------------- | :-------------------- | :------------------ | :--------------------------------------------------------------- |
| Can be instantiated | No         | Unknown status | Unknown identifiability | Forbidden         | Allowed               | none                | [occamy.schema.json*](occamy.schema.json "open original schema") |

## periph_axi_lite_narrow_plic_cfg Type

`integer`

## periph_axi_lite_narrow_plic_cfg Default Value

The default value is:

```json
1
```
