# Untitled array in Peripherals Schema Schema

```txt
http://pulp-platform.org/snitch/peripherals.schema.json#/properties/regbus_peripherals
```



| Abstract            | Extensible | Status         | Identifiable            | Custom Properties | Additional Properties | Access Restrictions | Defined In                                                                 |
| :------------------ | :--------- | :------------- | :---------------------- | :---------------- | :-------------------- | :------------------ | :------------------------------------------------------------------------- |
| Can be instantiated | No         | Unknown status | Unknown identifiability | Forbidden         | Allowed               | none                | [peripherals.schema.json*](peripherals.schema.json "open original schema") |

## regbus_peripherals Type

unknown\[]

## regbus_peripherals Constraints

**unique items**: all items in this array must be unique. Duplicates are not allowed.
