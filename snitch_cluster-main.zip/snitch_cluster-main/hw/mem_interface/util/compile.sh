#!/bin/bash
# Copyright 2020 ETH Zurich and University of Bologna.
# Solderpad Hardware License, Version 0.51, see LICENSE for details.
# SPDX-License-Identifier: SHL-0.51
#
# Fabian Schuiki <fschuiki@iis.ee.ethz.ch>
# Andreas Kurth  <akurth@iis.ee.ethz.ch>

set -e

[ ! -z "$VSIM" ] || VSIM=vsim

$BENDER script vsim -t test \
    --vlog-arg="-svinputport=compat" \
    --vlog-arg="-override_timescale 1ns/1ps" \
    --vlog-arg="-suppress 2583" \
    --vlog-arg="+cover=sbecft" \
    > compile.tcl
echo 'return 0' >> compile.tcl
$QUESTA_SEPP $VSIM -c -do 'exit -code [source compile.tcl]'
